# List of Twilight Temple Materials - Official PWpedia

This article contains a list of materials that can be found in [Twilight Temple](). The materials can be used to create [Twilight Temple Gear]().

## Contents

*   1 Common Materials
*   2 Act 1
*   3 Act 2
*   4 Act 3
*   5 Twilight Temple Revisited

## Common Materials

Common Materials may be obtained as either drops or dig materials throughout Twilight Temple. When harvested as dig materials, various Chests throughout the Twilight Temple will drop them, subject to drop rate modifications, including event double drops and earning time drop reduction.

| Material | Level | Dug From |
| --- | --- | --- |
|  \[Piece of Skeleton\] | 60 | 1-1, 1-2, 1-3 |
|  \[Mysterious Skull\] | 70 | 1-2, 1-3, 2-1, 2-2, 2-3 |
|  \[Klunky Sword\] | 80 | 2-1, 2-2, 2-3 |
|  \[Stone of Sacred Temple\] | 90 | 3-1, 3-2, 3-3 |
|  \[Sign of Twilight\] | 99 | 3-2, 3-3 |

## Act 1

| Material | Level | Act | Dropped By | Mode | Difficulty | Possible Product |
| --- | --- | --- | --- | --- | --- | --- |
|  \[Chientien's Edge\] | 60 | 1-1 | Chintien | Squad & Solo | 60-65 | [Weapon]() (Blade, Pike, Magic Sword, Saber) |
|  \[Broken Drum\] | 60 | 1-1 | Lord of Percussion | Squad & Solo | 60-65 | [Weapon]() (Dual Axes, Fists, Crossbow, Daggers, Soulsphere, Scythe) |
|   \[Chientien's Armor Shard\] | 70 | 1-2 | Chintien | Squad & Solo | 60-65 | [Weapon]() (Blade, Bow, Saber), [Ornament]() (Belt, Necklace) |
|  \[Framework of Drum\] | 70 | 1-2 | Lord of Percussion | Squad & Solo | 68-73 | [Armor]() (Wristguards), [Ornament]() (Ring) |
|  \[Soulgatherer's Tentacle\] | 70 | 1-2 | Soulbanisher | Squad | 68-73 | [Weapon]() (Wand, Pike, Fists, Crossbow) |
|  \[Broken Shard of Gold Armor\] | 70 | 1-2 | Dimentora | Squad | 68-73 | [Weapon]() (Poleblade, Magic Sword), [Armor]() (Body) |
|  \[Ancient Serpent's Skin\] | 70 | 1-2 | Vipenalt | Squad | 68-73 | [Weapon]() (Blade, Saber), [Armor]() (Footwear) |
|  \[Chin's Plate\] | 80 | 1-3 | Chintien | Squad & Solo | 76-81 | [Weapon]() (Pike, Crossbow), [Armor]() (Helm), [Ornament]() (Belt, Necklace) |
|  \[War Drum\] | 80 | 1-3 | Lord of Percussion | Squad & Solo | 76-81 | [Weapon]() (Glaive, Dual Axes, Pike, Fists, Bow, Daggers, Soulsphere, Scythe), [Armor]() (Helm), [Ornament]() (Ring) |
|  \[Soulgatherer's Mirror\] | 80 | 1-3 | Soulbanisher | Squad | 76-81 | [Weapon]() (Dual Swords, Fists), [Armor]() (Body), [Ornament]() (Belt, Necklace) |
|  \[Ancient Serpent's Blood\] | 80 | 1-3 | Vipenalt | Squad | 76-81 | [Weapon]() (Blade, Saber), [Armor]() (Footwear), [Ornament]() (Necklace, Ring) |
|  \[Ancient Serpent's Orb\] | 80 | 1-3 | Vipenalt | Squad | 76-81 | [Armor]() (Footwear, Gold Wristguards) |
|  \[Tough Shard of Gold Armor\] | 80 | 1-3 | Dimentora (Shooting Aur) | Squad | 76-81 | [Weapon]() (Pike, Magic Sword), [Armor]() (Footwear, Gold Wristguards) |
|  \[Golden Spirit\] | 80 | 1-3 | Dimentora (Shooting Aur) | Squad | 76-81 | [Weapon]() (Blade, Wand, Magic Sword, Bow, Crossbow, Saber) |

## Act 2

| Material | Level | Act | Dropped By | Mode | Difficulty | Possible Product |
| --- | --- | --- | --- | --- | --- | --- |
|  \[Frenzy Lion's Skin\] | 70 | 2-1 | Fataliqua | Squad & Solo | 74-79 | [Weapon]() (Dual Axes, Pike, Crossbow, Magic Sword, Daggers, Soulsphere, Scythe) |
|  \[Giant Ape's Tooth\] | 80 | 2-1 | Cosmoforce | Squad | 74-79 | [Weapon]() (Gold Fists, Blade, Pike, Dual Axes, Magic Sword, Crossbow, Daggers, Soulsphere, Saber, Scythe) |
|  \[Giant Ape's Palm\] | 80 | 2-1/2-2 | Cosmoforce | Squad | 74-79 | [Gold Weapon]() (Dual Axes, Pike, Poleblade, Fists, Daggers, Soulsphere, Scythe) |
|   \[Feng's Black Armor\] | 80 | 2-1 | General Feng | Squad & Solo | 74-79/82-87 | [Weapon]() (Dual Axes, Daggers, Soulsphere, Poleblade, Scythe), [Armor]() (Leggings, Wristguards) |
|  \[Feng's Steel Armor\] | 80 | 2-1/2-2 | General Feng | Squad & Solo | 74-79/84-87 | [Gold Armor]() (Body, Leggings) |
|  \[Claw of Consumer of Souls\] | 80 | 2-1 | Soulripper | Squad | 74-79 | [Weapon]() (Wand, Fists, Spears, Sword, Slingshot, Saber) |
|  \[Forshura's Armor\] | 70 | 2-1 | General Wurlord | Squad & Solo | 74-79 | [Weapon]() (Dual Axes, Crossbow, Daggers, Soulsphere, Scythe), [Armor]() (Leggings) |
|  \[Forshura's Black Orb\] | 70 | 2-1 | General Wurlord | Squad & Solo | 74-79 | [Gold Ornaments]() (Necklace, Belt, Ring) |
|  \[Frenzy Lion's Claw\] | 80 | 2-2 | Fataliqua | Squad & Solo | 82-87 | [Weapon]() (Sword, Dual Axes, Crossbow, Magic Sword, Daggers, Soulsphere, Saber, Scythe), [Armor]() (Wristguards) |
|  \[Frenzy Lion's Edge\] | 90 | 2-3 | Fataliqua | Squad & Solo | 82-87 | [Weapon]() (Sword, Spear, Saber) |
|  \[Giant Ape's Skin\] | 80 | 2-2 | Cosmoforce | Squad | 82-87 | [Weapon]() (Blade, Poleblade, Saber), [Armor]() (Leggings, Footwear) |
|  \[Feng's Iron Bars\] | 80 | 2-2 | General Feng | Squad & Solo | 82-87 | [Weapon]() (Dual Axes, Glaive, Bow, Crossbow, Daggers, Soulsphere, Scythe), [Armor]() (Gold Leggings) |
|  \[Mane of Consumer of Souls\] | 80 | 2-2 | Soulripper | Squad | 82-87 | [Weapon]() (Dual Axes, Magic Sword, Daggers, Soulsphere, Scythe), [Armor]() (Body) |
|  \[Forshura's Hook\] | 80 | 2-2 | General Wurlord | Squad & Solo | 82-87 | [Weapon]() (Dual Swords, Dual Axes, Blade... |

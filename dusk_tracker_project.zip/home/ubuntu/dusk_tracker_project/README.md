# Rastreador de Itens de Dusk - Perfect World

Este projeto contém os dados e scripts iniciais para um rastreador de itens do Palácio do Crepúsculo (Dusk) do jogo Perfect World. O objetivo é ajudar os jogadores a planejar e acompanhar a fabricação de equipamentos.

## Conteúdo do Projeto

*   `dusk_items_database.json`: Um arquivo JSON contendo uma estrutura inicial de dados dos itens de Dusk, incluindo materiais, receitas parciais e fontes. (Este arquivo é populado pelo script `process_dusk_data.py` e foi preenchido com dados de exemplo/parciais durante o desenvolvimento inicial).
*   `process_dusk_data.py`: Um script Python para processar dados de materiais de Dusk (extraídos de fontes como a PWpedia) e convertê-los para o formato JSON utilizado no `dusk_items_database.json`.
*   `architecture_plan.md`: Documento com o planejamento da arquitetura e tecnologias para a aplicação web completa.
*   `pwpedia_dusk_materials.md`: Dados brutos em Markdown extraídos da PWpedia sobre os materiais de Dusk.
*   `dusk_wiki_data.md`: Dados brutos em Markdown extraídos da Wiki PW (versão brasileira) sobre o Palácio do Crepúsculo.

## Como Usar (Estado Atual)

No estado atual, o projeto foca na coleta e estruturação dos dados dos itens.

1.  **Visualizar os Dados dos Itens:**
    *   Você pode abrir o arquivo `dusk_items_database.json` para ver a estrutura de dados dos itens que foi parcialmente populada.

2.  **Processar Dados (Opcional - para desenvolvedores):**
    *   Se você tiver o arquivo `pwpedia_dusk_materials.md` atualizado ou quiser modificar o script de processamento:
        *   Certifique-se de ter Python 3 instalado.
        *   Execute o script: `python process_dusk_data.py`
        *   Isso irá (re)gerar o arquivo `dusk_items_database.json` com base nos dados do `pwpedia_dusk_materials.md`.

## Próximos Passos (Desenvolvimento da Aplicação Web)

Conforme o `architecture_plan.md`, os próximos passos para transformar isso em uma aplicação web funcional seriam:

1.  **Desenvolver o Frontend:**
    *   Escolher um framework JavaScript (ex: React, Vue.js - React foi sugerido no plano).
    *   Criar os componentes da interface do usuário para:
        *   Seleção de personagens.
        *   Seleção de itens desejados por personagem.
        *   Visualização da árvore de progressão dos itens.
        *   Listagem consolidada de materiais.
        *   Marcação de progresso.
    *   Carregar e utilizar o `dusk_items_database.json` no frontend para popular a aplicação.
2.  **Lógica da Aplicação:**
    *   Implementar a lógica para calcular todos os materiais necessários recursivamente.
    *   Implementar o sistema de rastreamento de progresso.
    *   Permitir salvar/carregar o estado do planejamento (inicialmente via Local Storage).

## Como Publicar no seu GitHub

1.  **Crie um Novo Repositório no GitHub:**
    *   Vá para [https://github.com/new](https://github.com/new).
    *   Dê um nome ao seu repositório (ex: `pw-dusk-tracker`).
    *   Adicione uma descrição (opcional).
    *   Escolha se será público ou privado.
    *   **Não** inicialize com um README, .gitignore ou licença por enquanto (faremos isso manualmente ou você pode adicionar depois).
    *   Clique em "Create repository".

2.  **Faça o Upload dos Arquivos do Projeto:**
    *   Na página do seu novo repositório, você verá algumas opções. Clique em "uploading an existing file".
    *   Arraste a pasta `dusk_tracker_project` (ou os arquivos individuais de dentro dela, incluindo este `README.md`) para a área de upload.
    *   Aguarde o upload ser concluído.
    *   Adicione uma mensagem de commit (ex: "Commit inicial do projeto Rastreador de Dusk").
    *   Clique em "Commit changes".

3.  **(Opcional) Se você tiver Git instalado localmente e preferir usar a linha de comando:**
    *   Navegue até a pasta `dusk_tracker_project` no seu computador.
    *   Inicialize um repositório Git: `git init`
    *   Adicione os arquivos: `git add .`
    *   Faça o commit: `git commit -m "Commit inicial do projeto Rastreador de Dusk"`
    *   Adicione o repositório remoto (você encontrará o URL na página do seu GitHub, algo como `https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git`):
        `git remote add origin URL_DO_SEU_REPOSITORIO`
    *   Envie os arquivos para o GitHub: `git push -u origin main` (ou `master` dependendo da sua configuração padrão do Git).

Agora seu projeto estará no seu GitHub!

---

*Este README foi gerado para auxiliar no uso e continuação do desenvolvimento do Rastreador de Itens de Dusk.*

import json
import re

def parse_markdown_table(table_markdown):
    lines = table_markdown.strip().split('\n')
    if len(lines) < 2:
        return []

    header = [h.strip() for h in lines[0].strip('|').split('|')]
    data_lines = lines[2:] # Skip separator line

    parsed_data = []
    for line in data_lines:
        if not line.strip():
            continue
        values = [v.strip() for v in line.strip('|').split('|')]
        if len(values) == len(header):
            parsed_data.append(dict(zip(header, values)))
    return parsed_data

def extract_name_from_markdown_link(md_link):
    match = re.search(r'\[(.*?)\]', md_link) # Matches [Item Name]
    if match:
        return match.group(1).strip()
    return md_link.strip() # Return as is if no link pattern found


items_database = []

# Process Common Materials
try:
    with open("/home/ubuntu/pwpedia_dusk_materials.md", "r") as f:
        content = f.read()

    common_materials_section = content.split("## Common Materials")[1].split("## Act 1")[0]
    table_match = re.search(r'\| Material \| Level \| Dug From \|.*?(\n\|.*?\|.*?\|.*?\|)+', common_materials_section, re.DOTALL)

    if table_match:
        common_materials_table_md = table_match.group(0)
        parsed_common_materials = parse_markdown_table(common_materials_table_md)

        for mat in parsed_common_materials:
            item_name = extract_name_from_markdown_link(mat.get('Material', ''))
            item_id = item_name.lower().replace(' ', '_').replace('[','').replace(']','')
            items_database.append({
                "id": item_id,
                "name": item_name,
                "type": "material",
                "level": int(mat.get('Level', 0)) if mat.get('Level', '').isdigit() else 0,
                "icon": None,
                "recipe": [],
                "evolves_from": None,
                "evolves_to": None,
                "source": {
                    "type": "dig",
                    "details": f"Dug from {mat.get('Dug From', '')}"
                }
            })
    else:
        print("Common Materials table not found or regex failed.")

    # Placeholder for Act 1, Act 2, Act 3 processing - to be expanded
    # For now, just ensuring the JSON file is created with common materials if found

except Exception as e:
    print(f"Error processing common materials: {e}")


# Process Act 1 Materials (Simplified example - focusing on structure)
# This part needs more robust parsing for the complex 'Possible Product' and other fields.
# For now, I'll extract a few fields to demonstrate and build upon.
try:
    act1_section = content.split("## Act 1")[1].split("## Act 2")[0]
    act1_table_match = re.search(r'\| Material \| Level \| Act \| Dropped By \| Mode \| Difficulty \| Possible Product \|.*?(\n\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|)+', act1_section, re.DOTALL)

    if act1_table_match:
        act1_materials_table_md = act1_table_match.group(0)
        parsed_act1_materials = parse_markdown_table(act1_materials_table_md)

        for mat in parsed_act1_materials:
            item_name = extract_name_from_markdown_link(mat.get('Material', ''))
            item_id = item_name.lower().replace(' ', '_').replace('[','').replace(']','')
            
            # Avoid duplicates if already processed as a common material with the same ID
            if any(item['id'] == item_id for item in items_database):
                # Update existing item if necessary, or skip if it's just a source difference
                for existing_item in items_database:
                    if existing_item['id'] == item_id:
                        # Example: Add drop source if not already present or different
                        new_source_detail = f"Dropped by {mat.get('Dropped By', '')} in Act {mat.get('Act', '')} ({mat.get('Mode', '')} - {mat.get('Difficulty', '')})"
                        if isinstance(existing_item['source'], dict):
                            if existing_item['source']['details'] != new_source_detail:
                                # If source is a dict, make it a list to hold multiple sources
                                existing_item['source'] = [existing_item['source']]
                                existing_item['source'].append({
                                    "type": "drop",
                                    "details": new_source_detail
                                })
                        elif isinstance(existing_item['source'], list):
                            if not any(s['details'] == new_source_detail for s in existing_item['source']):
                                existing_item['source'].append({
                                    "type": "drop",
                                    "details": new_source_detail
                                })
                        break
                continue

            items_database.append({
                "id": item_id,
                "name": item_name,
                "type": "material", # Could also be 'weapon', 'armor' based on 'Possible Product'
                "level": int(mat.get('Level', 0)) if mat.get('Level','').isdigit() else 0,
                "icon": None,
                "recipe": [], # To be filled if this item is craftable
                "evolves_from": None,
                "evolves_to": None,
                "source": {
                    "type": "drop",
                    "details": f"Dropped by {mat.get('Dropped By', '')} in Act {mat.get('Act', '')} ({mat.get('Mode', '')} - {mat.get('Difficulty', '')})"
                },
                "dropped_by": [
                    {
                        "name": mat.get('Dropped By', ''),
                        "act": mat.get('Act', ''),
                        "mode": mat.get('Mode', ''),
                        "difficulty": mat.get('Difficulty', '')
                    }
                ],
                "possible_product_of": mat.get('Possible Product', '') # This needs further parsing
            })
    else:
        print("Act 1 Materials table not found or regex failed.")

except Exception as e:
    print(f"Error processing Act 1 materials: {e}")


with open("/home/ubuntu/dusk_items_database.json", "w") as outfile:
    json.dump(items_database, outfile, indent=4)

print(f"Processed {len(items_database)} items and saved to dusk_items_database.json")



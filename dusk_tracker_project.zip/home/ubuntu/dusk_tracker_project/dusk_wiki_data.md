# Palácio do Crepúsculo - Wiki PW

O Palácio do Crepúsculo pode ser acessado por personagens de qualquer nível diretamente através do portal em 130,668 ou pela missão “P. do Crepúsculo 60+” no NPC Pedra da Terra do Sonho na Cidade do Dragão ao custo de 8.000 moedas para personagens do nível 60 ou superior.

Já o Palácio do Crepúsculo Rapsódia I e II podem ser acessados por jogadores reborn 2, level 100+ e céu Oscilante I, também é necessário ter uma Entrada, a Ode da Ordem Lunar, adquirida dentro da entrada da Instância.

A entrada fica na Cidade de Fei Wei em 132,668 ou pelo NPC Pedra da Terra do Sonho na Cidade do Dragão.

Na instância normal é possível conseguir os itens para forja de equipamentos de nível 60~99 como armas, armaduras, colares, ornamentos e anéis. Ao entrar na instância, pode-se verificar nas fornalhas todo tipo de equipamento que pode ser forjado e os materiais necessários.

Na segunda parte Rapsódia I e II, é possível conseguir itens para forjar e reforjar os equipamento de Grade 17 (G17).

[]()

Pode-se forjar na fornalha “Essência” o item Essência do Crepúsculo, requerido para ativação de algumas dificuldades da instância. São necessários 05 Tábua Polida, 05 Aço Temperado, 05 Pó de Esmeril e 05 Carvão de Pedra para fabricação de uma Essência do Crepúsculo.

Para acessar a Instância dos capítulos 4 é necessário uma Ode da Ordem Lunar. A entrada diária é temporária, assim como a entrada da instância Submundo Frígido, sua duração é de 24 horas.

## Índice

*   1 Capítulos
*   2 Capítulo 1: Cântico Espiritual
*   3 Capítulo 2: Sinfonia do Destino
*   4 Capítulo 3: Ópera do Crepúsculo
*   5 Capítulo 4: Rapsódia I
*   6 Capítulo 4: Rapsódia II
*   7 Bosses
    *   7.1 Qin Tian
    *   7.2 Deus Tambor
    *   7.3 Emissário das Almas
    *   7.4 Serpente Ancestral
    *   7.5 Armadura Dourada
    *   7.6 Leão Insano Zhen Jun
    *   7.7 Marechal Shen Wuluo
    *   7.8 Marechal Feng Wuhen
    *   7.9 Grande Símio
    *   7.10 Devorador Insano
    *   7.11 Emissário das Sete Almas
    *   7.12 Aniquilador Ancestral
    *   7.13 Qiu Jian
    *   7.14 Escravo Demônio
    *   7.15 Mulher Demônio
    *   7.16 Tie Luoyun
    *   7.17 Rei Cang Li
    *   7.18 Grande Besta da Trevas
    *   7.19 Ministro Zi Cun
    *   7.20 Senhor das Ilusões
    *   7.21 Imperador do Crepúsculo
    *   7.22 O Ceifador Ressuscitado
    *   7.23 Ministro do Crepúsculo
    *   7.24 Armagedom
    *   7.25 Vingança Letal
    *   7.26 Ilusão de Nemem
    *   7.27 Senhor Alado
    *   7.28 Yi, o Terremoto e  Yi, o Asa Poderosa
    *   7.29 Yen Vendaval
    *   7.30 Príncipe Chongming
    *   7.31 Princesa do Luar Enlouquecida
*   8 Lista de prêmios

## Capítulos

[]()

Existem quatro capítulos que dividem os chefões da instância, note que cada capítulo possui três modos:

*   Capítulo 1: Cântico Espiritual
    *   Cavaleiros (60-65)
    *   Defensores (68-73)
    *   Valentes (76-81)
*   Capítulo 2: Sinfonia do Destino
    *   Valorosos (74-79)
    *   Heróicos (82-87)
    *   Iluminados (90-95)
*   Capítulo 3: Ópera do Crepúsculo
    *   Prestigiados (88-93)
    *   Sacerdotes (95-100)
    *   Santos (100+)
*   Capítulo 4: Rapsódia I
*   Capítulo 4: Rapsódia II

Cada um dos capítulos são divididos em três modos começando do mais fácil e dificultando a cada avanço, cada modo também separa o material que será obtido ao derrotar cada um dos chefões.

## Capítulo 1: Cântico Espiritual

Se desejar iniciar sua aventura pelo primeiro capítulo, fale com o NPC Capítulo 1: Cântico Espiritual e escolha a missão Cântico Espiritual para derrubar o portão que dá acesso a seu portal de entrada.

Ao atravessar pelo portal os jogadores serão teleportado à uma sala e deverão falar com o NPC “Seleção de Modo” para definir como desejam prosseguir, _Modo Solo_ indicado para os jogadores que pretendem fazer tudo sozinho ou _Modo Grupo_ indicado para aqueles que estão acompanhados de pelo menos mais 3 jogadores.

No modo solo do Cântico Espiritual estão disponíveis 3 níveis de dificuldade, Cavaleiros (60-65), Defensores (68-73) e Valentes . De acordo com a escolha do líder do grupo os itens poderão ser alterados.

Para ambas dificuldades, tanto para o “Chefe Alto” quanto “Chefe Médio”, estarão disponíveis os bosses Qin Tian e Deus Tambor variando apenas os itens que cada um deixará cair ao ser derrotado.

Se a instância for ativada no modo Defensores (68-73) ou Valentes (76-81) estarão disponíveis também o Emissário das Almas, Serpente Ancestral e Armadura Dourada no modo Grupo com dificuldade Alta.

Para este Capítulo são necessárias 1 Essência do Crepúsculo para se ativar a dificuldade Alta.

## Capítulo 2: Sinfonia do Destino

No modo mais fácil deste capítulo, Valorosos (74-79), encontram-se o Leão Insano Zhen Zhun, o Marechal Shen Wuluo e o Marechal Feng Wuhen na dificuldade Média e Alta tanto para os modos Solo quanto para o modo Grupo. E o Grande Símeo e Devorador Insano apenas no modo Grupo com a dificuldade Alta.

Já no modo Heróicos (82-87), além de todos os chefes mencionados acima está o Emissário das Sete Almas apenas na dificuldade Alta do modo Grupo.

E para o modo inclui-se o boss Iluminados (90-95) no modo Grupo com a dificuldade Alta.

É necessário que se derrote certa quantidade de monstros para que se enfraqueça cada um dos bosses da seguinte maneira:

*   Leão Insano Zhen Jun: 3
*   Marechal Shen Wuluo: 10
*   Marechal Feng Wuhen: 10
*   Grande Símeo: 10
*   Devorador Insano: 20
*   Emissário das Sete Almas: 20
*   Aniquilador Ancestral: 20

Se a quantidade de monstros indicada não for atingida, o chefe atacará com toda sua fúria, causando um dano extremamente alto em qualquer personagem.

Para este Capítulo são necessárias 2 Essências do Crepúsculo para se ativar a dificuldade Alta.

## Capítulo 3: Ópera do Crepúsculo

O terceiro Capítulo se torna mais difícil e é voltado aos jogadores que estão em busca de equipamentos superiores, de nível 90 ou 99 contando com nove chefes poderosos. No modo mais simples, Prestigiados (88-93), estão seis bosses, sendo o Qui Jian, Escravo Demônio, Mulher Demônio no modo Grupo ou Solo e nas dificuldades Média e Alto, enquanto que a Sagrada Mãe das Almas, Grande Besta das Trevas e Tie Luoyun aparecem apenas no modo Grupo com a dificuldade Alta.

Quando ativada como Sacerdotes (95-100), os mesmos chefes acima estarão disponíveis, além do Ministro Zi Cun e Rei Cang Li apenas na dificuldade Alta do modo Grupo.

Assim como no capítulo anterior, é necessário que se derrote alguns monstros antes de enfrentar os bosses, na Ópera do Crepúsculo a distribuição é:

*   Qiu Jian: 12
*   Escravo Demônio: 20
*   Mulher Demônio: 20
*   Tie Luoyun: 35
*   Grande Besta: 35
*   Sagrada Mãe das Almas: 25
*   Rei Cang Li: 40
*   Ministro do Crepúsculo: Maldito - 40
*   Lorde de Ilusão: Armagedon - 45

Caso a quantidade de monstros indicada não for atingida, o chefe atacará com toda sua fúria, causando um dano extremamente alto em qualquer personagem.

Por fim, em Santos (100+), todos os chefes estão disponíveis, incluindo o temido Senhor das Ilusões.

Para este Capítulo são necessárias 3 Essências do Crepúsculo para se ativar a dificuldade Alta.

## Capítulo 4: Rapsódia I

A continuação da história do Palácio do Crepúsculo ganha novos personagens, bosses e um novo nível de dificuldade.Os novos Bosses possuem habilidades especiais e as recompensas são usadas na forja dos novos equipamentos End Game.

Para ativar a instância são necessários dez membros em uma equipe. Todos devem possuir a entrada e estarem juntos para ativar.

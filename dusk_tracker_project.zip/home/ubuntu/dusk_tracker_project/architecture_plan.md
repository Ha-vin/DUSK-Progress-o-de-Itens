# Plano de Arquitetura e Tecnologias: Rastreador de Itens Dusk (Perfect World)

## 1. Visão Geral

O objetivo é desenvolver uma aplicação web para ajudar jogadores de Perfect World a rastrear os materiais e a progressão necessários para fabricar equipamentos do Palácio do Crepúsculo (Dusk) para múltiplos personagens de uma equipe.

A aplicação permitirá ao usuário:

*   Selecionar os personagens da equipe.
*   Escolher os itens finais de Dusk desejados para cada personagem.
*   Visualizar a árvore de progressão completa para cada item (incluindo itens intermediários e materiais básicos).
*   Ver uma lista consolidada de todos os materiais básicos necessários.
*   Marcar materiais como "obtidos" e itens como "fabricados".
*   Acompanhar o progresso geral.
*   Salvar e carregar o planejamento.
*   Identificar por onde começar o processo de fabricação com base nos itens já possuídos ou nos que faltam.

## 2. Arquitetura Proposta

**Tipo de Aplicação:** Aplicação Web de Página Única (Single Page Application - SPA).

**Componentes Principais:**

*   **Frontend:** Responsável pela interface do usuário, lógica de visualização, interações e gerenciamento do estado da aplicação no lado do cliente.
*   **Armazenamento de Dados dos Itens:** Os dados sobre os itens de Dusk (receitas, progressão, drops) serão armazenados em um formato estruturado (JSON) e carregados pelo frontend.
*   **Armazenamento de Dados do Usuário:** O progresso do usuário (itens selecionados, materiais obtidos) será salvo localmente no navegador.

## 3. Tecnologias Sugeridas

*   **Frontend:**
    *   **Framework JavaScript:** Vue.js (alternativa: React). Escolhido pela sua curva de aprendizado progressiva e bom desempenho para SPAs interativas.
    *   **Linguagem:** JavaScript (ES6+).
    *   **Estilização:** CSS puro, ou um framework CSS como Tailwind CSS ou Bootstrap para acelerar o desenvolvimento da UI.
    *   **HTML.
*   **Dados dos Itens de Dusk:**
    *   Formato: JSON. Um ou mais arquivos JSON contendo a definição de todos os itens, materiais, receitas e árvores de progressão.
*   **Persistência de Dados do Usuário (Progresso):**
    *   **Inicialmente:** Local Storage do navegador. Permite salvar o estado da aplicação diretamente no navegador do usuário.
    *   **Futuramente (Opcional):** Poderia ser estendido para um backend simples (ex: Python/Flask + SQLite ou Node.js/Express + SQLite/MongoDB) para permitir salvamento na nuvem e sincronização entre dispositivos, mas isso está fora do escopo inicial.

## 4. Estrutura de Dados dos Itens (Detalhes em `data_structure.md`)

Será definida uma estrutura JSON clara para representar cada item, incluindo:

*   `id`: Identificador único.
*   `name`: Nome do item.
*   `type`: ("weapon", "armor_heavy", "armor_light", "armor_robe", "ornament", "material").
*   `level`: Nível do item/material.
*   `icon`: (Opcional) Caminho para um ícone do item.
*   `recipe`: Array de objetos, cada um especificando um `item_id` de um componente e a `quantity` necessária. Pode incluir um campo `action` (ex: "craft", "break_down_previous_tier").
*   `evolves_from`: `item_id` do item de tier anterior (se aplicável).
*   `evolves_to`: `item_id` do item do próximo tier (se aplicável).
*   `source`: Como obter (ex: "craft", "drop", "dusk_chapter_X_boss_Y").

## 5. Funcionalidades Chave e Lógica

*   **Seleção de Itens:** O usuário poderá navegar ou pesquisar itens de Dusk e adicioná-los à sua lista de desejos por personagem.
*   **Cálculo de Materiais:** A aplicação irá recursivamente "explodir" os itens finais em seus componentes até chegar aos materiais básicos, somando as quantidades totais necessárias.
*   **Rastreamento de Progresso:** O usuário poderá marcar itens/materiais como obtidos. O sistema recalculará as necessidades restantes.
*   **Visualização da Árvore de Progressão:** Para cada item final, mostrar graficamente ou em lista os passos de fabricação.
*   **Priorização:** O sistema poderá sugerir por onde começar com base nos itens que faltam e suas dependências.

## 6. Interface do Usuário (Esboço)

*   **Página Principal:**
    *   Seção para gerenciar a equipe (adicionar/remover personagens, nomeá-los).
    *   Para cada personagem:
        *   Slots de equipamento (Arma, Elmo, Peitoral, Calça, Bota, Bracelete, Colar, Ornamento Esquerdo, Ornamento Direito).
        *   Botão para adicionar/selecionar item de Dusk para cada slot.
    *   Visão geral consolidada de todos os materiais básicos necessários para a equipe.
    *   Barra de progresso geral.
*   **Modal/Página de Seleção de Item:**
    *   Filtros por tipo de item, nível, classe (se aplicável).
    *   Lista de itens de Dusk com seus nomes e ícones.
*   **Visualização de Item/Progresso:**
    *   Nome do item final.
    *   Árvore de fabricação (itens intermediários e materiais básicos).
    *   Checkboxes para marcar cada componente como "obtido" ou "fabricado".
    *   Opção para indicar se um item intermediário já é possuído.

## 7. Próximos Passos no Planejamento

1.  Finalizar a estrutura detalhada dos arquivos JSON para os dados dos itens de Dusk.
2.  Planejar a estrutura de componentes da aplicação Vue.js.
3.  Definir o formato de como os dados do usuário (seleções e progresso) serão armazenados no Local Storage.

